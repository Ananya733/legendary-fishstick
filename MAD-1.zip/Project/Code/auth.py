import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from db import get_db

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        email = request.form['email']
        phone = request.form['phone']
        shipping_addr = request.form['shipping_addr']
        city = request.form['city']
        state = request.form['state']
        country = request.form['country']
        PIN = request.form['PIN']
        db = get_db()
        error = None
        
        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
            
        if error is None:
            try:
                db.execute(
                    "INSERT INTO User (username, password, firstname, lastname, email, phone, shipping_addr, city, state, country, PIN) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",
                    (username, generate_password_hash(password), firstname, lastname, email, phone, shipping_addr, city, state, country, PIN),
                )
                db.commit()
            except db.IntegrityError:
                error = f"User {username} is already registered."
            else:
                return redirect(url_for("auth.login"))
            
        flash(error)
       
    return render_template('auth/register.html')


@bp.route('/adminregister', methods=('GET', 'POST'))
def adminregister():
    try:
        print('I am in admin register')
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            db = get_db()
            error = None        
            if not username:
                error = 'Username is required.'
            elif not password:
                error = 'Password is required.'
                
            if error is None:
                try:
                    db.execute(
                        "INSERT INTO admin (admin_code, password) VALUES (?, ?)",
                        (username, generate_password_hash(password)),
                    )
                    db.commit()
                except db.IntegrityError as e:                  
                    error = e
                else:
                    return redirect(url_for("auth.adminlogin"))                
            flash(error)        
    except Exception as e:           
            print('errormessage is' + e)
    return render_template('auth/adminregister.html')
    
@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = \'' + username + '\''
        ).fetchone()
        
        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
            
        if error is None:
            session.clear()
            session['user_id'] = user['user_id']
            session['admin'] = 0
            session['_productcode'] = None
            session['inError'] = 'No'
            session['greetingName'] = user['firstname'] + ' ' + user['lastname']
            print('hey '+  session['greetingName'] )
            return redirect(url_for('cart.SearchAndAdd', fromPage='homepage',productid='None'))
        
        flash(error)
        
    return render_template('auth/login.html')

@bp.route('/adminlogin', methods=('GET', 'POST'))
def adminlogin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM admin WHERE admin_code = \'' + username + '\''
        ).fetchone()
        
        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'
            
        if error is None:
            session.clear()
            session['user_id'] = user['admin_code']
            session['admin'] = 1
            return redirect(url_for('cart.admin'))
        
        flash(error)
        
    return render_template('auth/adminlogin.html')


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')
    admin = session.get('admin')
    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT product_name,price FROM Product'
        ).fetchone()
    if admin == 1:
        g.admin = 1

@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))
    
def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))
            
        return view(**kwargs)
        
    return wrapped_view