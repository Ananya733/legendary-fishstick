from flask import(
    Flask, Blueprint, flash, g, redirect, render_template, request, url_for, session
)
import os
import datetime

from auth import login_required
from db import get_db

from datetime import date

app = Flask(__name__,  static_folder = "static")


bp = Blueprint('cart', __name__)

def convertToBinaryData(filename):
  # Convert binary format to images or files data  
  with open( filename, 'rb') as file:
      blobData = file.read()
  return blobData

#write binary data to image file
def write_to_file(binary_data, file_name):   
  file_name = os.path.join(app.root_path, 'static', 'images', file_name)
  print('file name in write to file=' + file_name)
  with open(file_name, 'wb') as file:
    file.write(binary_data)

def search_products(searchTerm):
    db = get_db()
    products = db.execute(
            'select product_name,price,section_id,images, image_name from Product'
    ).fetchall()        
    return products

@bp.route('/')
def index():
    return render_template('cart/index.html')

@bp.route('/admin')
def admin():
    return render_template('cart/adminindex.html')

@bp.route('/createProduct', methods=('GET','POST'))
@login_required
def createProduct():
    db = get_db()
    sections = db.execute(
       'SELECT * FROM Section'
    ).fetchall()
    fileuploaded = 0
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        availableqty = request.form['availableqty']
        body = request.form['body']
        unitofmeasure = request.form['unitofmeasure']
        sectionid = request.form['sectionid']
     
        if request.form['mfgDate'] != '':
            date1 = datetime.datetime.strptime(request.form['mfgDate'], "%Y-%m-%d")
            date2 = str(date1.strftime('%Y-%m-%d')) 
            print('date2=' + date2)

        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
                fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
      
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                   'INSERT INTO Product (product_name,price, Manufacture_or_Expiry_Date, measure_of_units, available_qty, section_id,images, image_name)'
                  ' VALUES (?,?,?,?,?,?,?,?)',
                (title, body, date2, unitofmeasure, availableqty, sectionid, imagef,f.filename)
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                    'INSERT INTO Product (product_name,price,Manufacture_or_Expiry_Date, measure_of_units, available_qty, section_id )'
                  ' VALUES (?,?,?,?,?,?)',
                (title, body, date2, unitofmeasure, availableqty, sectionid)
                )
                db.commit()
             return redirect(url_for('cart.showAndModifyProducts'))
             
        except Exception as e:
            fileuploaded=0
            print(e)       

        error = None
        
        if not title:
            error = 'Title is required.'    
    return render_template('cart/createProduct.html', sections = sections)

@bp.route('/createSection', methods=('GET','POST'))
@login_required
def createSection():
    
    fileuploaded = 0
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
               fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                    'INSERT INTO section (section_name,section_description,image,image_name )'
                  ' VALUES (?,?,?,?)',
                (title, body, imagef,f.filename)
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                    'INSERT INTO section (section_name,section_description)'
                  ' VALUES (?,?)',
                (title, body)
                )
                db.commit()
             return redirect(url_for('cart.showAndModifySections'))
             
        except Exception as e:
            fileuploaded=0
            print(e)       

        error = None
       
        if not title:
            error = 'Title is required.'
            
        if error is not None:
            flash(error)
      
    return render_template('cart/createSection.html')
    

@bp.route('/addToCart', methods=('GET','POST'))
@login_required
def addToCart():
    
    try:   
        if request.method == 'POST':
            db = get_db()
            sections = db.execute(
                'select section_id, section_name from Section' 
            ).fetchall()

            product_id = request.form['productId']
            qty = request.form['quantity']
            
            _code = request.form['productId']
            _quantity = int(request.form['quantity'])

            if int(qty) <= 0:
                error="invalid literal for int()"
                raise ValueError(error)
            error = None
            print ("product_id = " , product_id)
           
                    
            user_id = session.get('user_id')    
            db = get_db()
            cart = db.execute(
                'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and user_id = ' + str(user_id) 
            ).fetchone()
            if cart is None:
                db.execute(
                    'INSERT INTO Cart (user_id, total_quantity, total_price, order_placed)'
                        ' VALUES (?,?,?,?)',
                        (user_id,0,0,'No') 
                )      
                db.commit()    
                cart = db.execute(
                'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and user_id = ' + str(user_id) 
                ).fetchone()

            cart_id =cart['cart_id']
            session['cart_id'] = cart_id
            searchTerm = session.get('searchTerm')        
            if searchTerm:
                print("searchTerm===" + searchTerm)      
                products = db.execute(
                        'select product_id, product_name,price,section_id,images, image_name from Product where product_name like \'%' + searchTerm + '%\''
                ).fetchall()           
            else:   
                products = db.execute(
                        'select product_id, product_name,price,section_id,images, image_name from Product'
                ).fetchall()  
                print("No search Term here:::")      
                
        
            
            
            
            # validate the received values
            if _quantity and _code and request.method == 'POST':
                product = db.execute(
                    'select product_id, available_qty, product_name,price,p.section_id, c.section_name, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, p.images, p.image_name from Product p, section c where p.section_id = c.section_id and product_id = ' + _code + ''
                ).fetchone() 
                
                itemArray = { str( product['product_id'] ) : {'name' : product['product_name'], 'code' : product['product_id'],  'Manufacture_or_Expiry_Date' : product['Manufacture_or_Expiry_Date'],  'section_name' : product['section_name'], 'quantity' : _quantity, 'price' : product['price'], 'image_name' : product['image_name'], 'total_price': _quantity * product['price']}}
                
                all_total_price = 0
                all_total_quantity = 0
                
                session.modified = True
                if 'cart_item' in session:
                    if str(product['product_id']) in session['cart_item']:
                    #if product['product_id'] in session['cart_item']:
                        for key, value in session['cart_item'].items():
                            print('dictionary key==' + str(key))
                            if str(product['product_id']) == key:
                                #session.modified = True
                                #if session['cart_item'][key]['quantity'] is not None:
                                #	session['cart_item'][key]['quantity'] = 0
                                            
                                old_quantity = session['cart_item'][key]['quantity']
                                total_quantity = old_quantity + _quantity
                                if total_quantity > product['available_qty']:
                                    error="Only " + str(product['available_qty']) + " units are available."
                                    raise ValueError(error)
                                session['cart_item'][key]['quantity'] = total_quantity
                                session['cart_item'][key]['total_price'] = total_quantity * product['price']
                    else:
                        session['cart_item'] = array_merge(session['cart_item'], itemArray)
                    for key, value in session['cart_item'].items():
                        individual_quantity = int(session['cart_item'][key]['quantity'])
                        individual_price = float(session['cart_item'][key]['total_price'])
                        all_total_quantity = all_total_quantity + individual_quantity
                        all_total_price = all_total_price + individual_price
                else:
                    print('building cart_item in session')
                    
                    if _quantity > product['available_qty']:
                            error="Only " + str(product['available_qty']) + " units are available."
                            raise ValueError(error)
                          
                    session['cart_item'] = itemArray
                    all_total_quantity = all_total_quantity + _quantity
                    all_total_price = all_total_price + _quantity * product['price']
                
                session['all_total_quantity'] = all_total_quantity
                session['all_total_price'] = all_total_price
                print("I am here 1:" + str(all_total_quantity) + ":" + str(all_total_price) + ":" + str(searchTerm) + ":" + str(cart_id) )
            else:			
                print("I am here 2")			
                return 'Error while adding item to cart'
    except Exception as e:
        #error=f"There was error while adding to the cart"
        error = str(e)
    finally:
        print("session = " + str(session.get('all_total_quantity')))
        #return render_template('cart/SearchAndAdd.html', products = products, sections=sections, searchTerm=searchTerm, cartid=cart_id)
        print('***setting from Page to addToCart' + str(_code))
        print('error message is' + str(error))
        if str(error) != 'None':
            if  "invalid literal for int()" in str(error):
                error="Quantity can only be greater than 0."
            flash(error)
            session['inError'] = 'Yes'
        else:
            session['inError'] = 'No'        
        session['_productcode'] = _code
        return redirect(url_for('cart.SearchAndAdd', fromPage='addToCart'))

def array_merge( first_array , second_array ):
        if isinstance( first_array , list ) and isinstance( second_array , list ):
            return first_array + second_array
        elif isinstance( first_array , dict ) and isinstance( second_array , dict ):
            dict1 =dict( list( first_array.items() ) + list( second_array.items() ) ) 
            return dict( list( first_array.items() ) + list( second_array.items() ) )
        elif isinstance( first_array , set ) and isinstance( second_array , set ):
            return first_array.union( second_array )
        return False

def build_cart_session():
    user_id = session.get('user_id')    
    db = get_db()
    cart = db.execute(
        'select cart_id, user_id, total_quantity, total_price from Cart where order_placed=\'No\' and user_id = ' + str(user_id) 
    ).fetchone()        
    
    if not cart is None:
        session['cart_id']=int(cart['cart_id'])
        session['all_total_quantity'] = int(cart['total_quantity'])
        session['all_total_price'] = float(cart['total_price'])
        cartItems = db.execute(
        'select cart_id,total_price,ci.product_id, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, section_name, product_quantity, product_name, price, images, p.image_name from Cart_item ci, product p, section s where s.section_id=p.section_id and p.product_id = ci.product_id and cart_id = ' + str(cart['cart_id']) 
        ).fetchall() 
    
        for row in cartItems:
            print('row=' + str(row))
            itemArray = { str( row['product_id'] ) : {'name' : row['product_name'], 'code' : row['product_id'],  'Manufacture_or_Expiry_Date' : row['Manufacture_or_Expiry_Date'],  'section_name' : row['section_name'], 'quantity' : row['product_quantity'], 'price' : row['price'], 'image_name' : row['image_name'], 'total_price': row['total_price']}}
            
            if 'cart_item' in session:
                session['cart_item'] = array_merge(session['cart_item'], itemArray)                
            else:
                session['cart_item'] = itemArray        


@bp.route('/SearchAndAdd/<string:fromPage>', methods=('GET','POST'))
@login_required
def SearchAndAdd(fromPage):
   
   if not 'cart_item' in session:
        build_cart_session()
   
   searchTerm=''  
   additionalFilter = ' '
   sectionFilter = ' '
   db = get_db()
   sections = db.execute(
        'select section_id, section_name from Section' 
   ).fetchall()

   if fromPage == 'showCart':
       session['inError']='No'
       
   print('****From Page=' +fromPage)
   if request.method == 'POST':       
        
        searchTerm = request.form['searchTerm']       
        
        fromPrice=str(request.form['fromPrice'])
        toPrice=str(request.form['toPrice'])
        print ("fromPrice = " , fromPrice)
        print ("toPrice = " , toPrice)        
        if fromPrice:
            additionalFilter += 'AND PRICE >= ' + fromPrice
        if toPrice:
                additionalFilter += ' AND PRICE <= ' + toPrice        
        error = None
        
        fromDate=str(request.form['fromDate'])
        toDate=str(request.form['toDate'])
        print ("fromDate = " , fromDate)
        print ("toDate = " , toDate)        

        print ("searchTerm = " , searchTerm)
        print ("additionalFilter = " , additionalFilter)
        session['searchTerm']=searchTerm
        session['fromPrice']=fromPrice
        session['toPrice']=toPrice
        session['fromDate']=fromDate
        session['toDate']=toDate

        if fromDate:
            additionalFilter += 'AND ( Manufacture_or_Expiry_Date = \'\' OR strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) >= \'' + fromDate + '\')'
        if toDate:
            additionalFilter += ' AND ( Manufacture_or_Expiry_Date = \'\' OR strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) <= ' '\'' + toDate + '\')'        
        
        session['additionalFilter'] = additionalFilter

        sectionCounter = -1
        for sec in sections:
            try:
                if not request.form[sec['section_name']] is None:
                    session[sec['section_name']]=True
                    if sectionCounter == -1:
                        sectionFilter += ' AND ( p.SECTION_ID = ' + request.form[sec['section_name']]                        
                    else:
                        sectionFilter += '  OR p.SECTION_ID = ' + request.form[sec['section_name']]
                    sectionCounter += 1
            except Exception as e:
                session[sec['section_name']]=False
                print(e)        
        if sectionFilter != ' ':
            sectionFilter += ' )'
        session['sectionFilter'] = sectionFilter
        
        if not searchTerm:
            error = 'searchTerm is required.'
            
        if error is not None:
            flash(error)
   else:
        if 'searchTerm' in session:
            searchTerm = session['searchTerm']
            additionalFilter = session['additionalFilter']
            sectionFilter = session['sectionFilter']      
            print('****searchTerm='+searchTerm)
            print('****additionalFilter='+additionalFilter)
            print('****sectionFilter='+sectionFilter)
  
   finalquery = 'select product_id, product_name,price, p.section_id, p.measure_of_units, p.available_qty, s.section_name, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, images, p.image_name from Product p, section s where p.section_id=s.section_id and product_name like \'%' + searchTerm + '%\' ' + additionalFilter + sectionFilter
   print('finalquery = ' +finalquery)
   '''
   products = db.execute(
            'select product_id, product_name,price, p.section_id, p.measure_of_units, p.available_qty,  s.section_name, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, images, p.image_name from Product p, section s where p.section_id=s.section_id and product_name like \'%' + searchTerm + '%\' ' + additionalFilter + sectionFilter
   ).fetchall()  '''
   products = db.execute(
       'select product_id, product_name,price, p.section_id, p.measure_of_units, p.available_qty,  s.section_name, strftime(\'%d-%m-%Y\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, images, p.image_name from Product p, section s where p.section_id=s.section_id and product_name like \'%' + searchTerm + '%\' ' + additionalFilter + sectionFilter
   ).fetchall()
   if products is None:
        return render_template('cart/SearchAndAdd.html',  sections=sections,searchTerm=searchTerm)
   else:
        return render_template('cart/SearchAndAdd.html', products = products, sections=sections,searchTerm=searchTerm)

@bp.route('/showCart', methods=('GET',))
@login_required
def showCart():  
    session['inError']  = 'No'
    if not 'cart_item' in session:
        build_cart_session() 
    return render_template('cart/showCart.html')


@bp.route('/delete/<string:code>')
@login_required
def remove_product(code):
	try:
		all_total_price = 0
		all_total_quantity = 0
		session.modified = True
		
		for item in session['cart_item'].items():
			if item[0] == code:				
				session['cart_item'].pop(item[0], None)
				if 'cart_item' in session:
					for key, value in session['cart_item'].items():
						individual_quantity = int(session['cart_item'][key]['quantity'])
						individual_price = float(session['cart_item'][key]['total_price'])
						all_total_quantity = all_total_quantity + individual_quantity
						all_total_price = all_total_price + individual_price
				break
		
		if all_total_quantity == 0:
			session.clear()
		else:
			session['all_total_quantity'] = all_total_quantity
			session['all_total_price'] = all_total_price		

		return render_template('cart/showCart.html')
	except Exception as e:
		print(e)

@bp.route('/go_back')
@login_required
def go_back():
    try:
        #session.clear()
        return redirect(url_for('.searchAndAdd'))
    except Exception as e:
        print(e)

@bp.route('/save_cart')
@login_required
def save_cart():
    try:
        if session['cart_item'] is None:
            print('about to call build_cart_session')
            build_cart_session()
        if session['cart_item'] is not None:
            #session.clear()
            #update cart record first
            user_id = int(session.get('user_id'))
            db = get_db()
            db.execute(
                'UPDATE Cart SET total_price = ?, total_quantity = ?'
                ' WHERE order_placed = \'No\' and user_id = ? ',
                (float(session['all_total_price']), int(session['all_total_quantity']), user_id)
            )
            db.commit()
            print("after save cart" + str(session['all_total_price']) + ':' + str(session['all_total_quantity']) + ":" + str(user_id) + ":" + str(session['cart_id']))
            #delete any existing cart items
            cart_id = int(session['cart_id'])
            print("cart id ==" + str(cart_id))
            db.execute(
                'delete from cart_item'
                ' WHERE cart_id = ?',
                (cart_id,)
            )
            db.commit()
            
            print("after delete cart items")
            #add items from session to cart items
            for key, value in session['cart_item'].items():
                individual_quantity = int(session['cart_item'][key]['quantity'])
                individual_price = float(session['cart_item'][key]['total_price'])
                product_id = int(session['cart_item'][key]['code'])
                cart_id = int(session['cart_id'])
                print("cart item=" + str(cart_id) + ":" + str(individual_price) + ":" + str(product_id) + ":" + str(individual_quantity))
                
                db.execute(
                    'INSERT INTO cart_item (cart_id,total_price,product_id, product_quantity)'
                    ' VALUES (?,?,?,?)',
                    (cart_id, individual_price, product_id,individual_quantity))
                db.commit()
                
            print("after save cart items")            
    except Exception as e:
        print(e)
    finally:
        return redirect(url_for('.SearchAndAdd', fromPage='saveCart'))   

@bp.route('/showAndModifyProducts/', methods=('GET','POST'))
@login_required
def showAndModifyProducts():
   sectionid=''
   finalquery = 'select product_id, product_name,price, measure_of_units, available_qty, p.section_id, c.section_name, strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, p.images, p.image_name from Product p , section c where p.section_id=c.section_id'
   if request.method == 'POST':
        sectionid = str(request.form['sectionid'])
        if sectionid == '':
            finalquery = 'select product_id, product_name,price, measure_of_units, available_qty, p.section_id, c.section_name, strftime(\'%Y-%m-%d\', Manufacture_or_Expiry_Date) as Manufacture_or_Expiry_Date, p.images, p.image_name from Product p left join section c on p.section_id=c.section_id'
        else:
            finalquery = finalquery + ' and p.section_id = ' + sectionid 
       
   db = get_db()
   sections = db.execute(
        'select section_id, section_name from Section' 
   ).fetchall()
  
   print('finalquery = ' +finalquery)
   products = db.execute(finalquery).fetchall() 
   print('sectionid='+sectionid)
   return render_template('cart/showAndModifyProducts.html', products = products, sections=sections, sectionid=sectionid)

@bp.route('/delete_product/<string:code>')
@login_required
def delete_product(code):
    db = get_db()
    db.execute(
        'delete from product'
        ' WHERE product_id = ?',
        (code,)
    )
    db.commit()    
    return redirect(url_for('cart.showAndModifyProducts'))
@bp.route('/update_product/', methods=('GET','POST'))
@login_required
def update_product():
     
    date2=''
    print(request.files)
    fileuploaded = 0
    imagef=''
    f=''
    filename1=''
    if request.method == 'POST':
        sectionid = str(request.form['sectionid'])
        productid = str(request.form['productid'])
        productname = str(request.form['productname'])
        price = str(request.form['price'])
        quantity = str(request.form['quantity'])
        units = str(request.form['units'])

        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
               fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)             
      
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)

        if request.form['mfgDate'] != '':
            date1 = datetime.datetime.strptime(request.form['mfgDate'], "%Y-%m-%d")
            date2 = str(date1.strftime('%Y-%m-%d')) 
            print('date2=' + date2)
        print('values=' + sectionid + productid + price + quantity + date2)
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                    'UPDATE product SET price = ?, available_qty = ?, section_id = ?, product_name = ?, images = ?, image_name = ?, Manufacture_or_Expiry_Date = ?, measure_of_units = ?'
                        ' WHERE product_id = ?',
                        (price, quantity, sectionid, productname, imagef, f.filename, date2,units, productid)    
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                    'UPDATE product SET price = ?, available_qty = ?, section_id = ?, product_name = ?, Manufacture_or_Expiry_Date = ?, measure_of_units = ?'
                        ' WHERE product_id = ?',
                        (price, quantity, sectionid, productname, date2,units, productid)    
                )
                db.commit()
             
        except Exception as e:
            fileuploaded=0
            print(e)             
        

   
    return redirect(url_for('cart.showAndModifyProducts'))


@bp.route('/showAndModifySections/', methods=('GET','POST'))
@login_required
def showAndModifySections():

   finalquery = 'select section_id, section_name,section_description, image, image_name from section'
  

   db = get_db()   
   sections = db.execute(finalquery).fetchall()

   return render_template('cart/showAndModifySections.html', sections=sections)

@bp.route('/update_section/', methods=('GET','POST'))
@login_required
def update_section():
    date2=''
    print(request.files)
    fileuploaded = 0
    imagef=''
    f=''
    filename1=''
    if request.method == 'POST':
        sectionid = str(request.form['sectionid'])
        desciption = str(request.form['SectionDescription'])
        sectionname = str(request.form['SectionName'])
        

        try:       
            f=request.files['image']
            if not "FileStorage: ''" in str(f): 
                fileuploaded=1
        except Exception as e:
            fileuploaded=0
            print(e)  
        
        print('filename' + str(fileuploaded))
        if fileuploaded==1:
            f = request.files['image']
            f.save(f.filename)            
            imagef = convertToBinaryData(f.filename)
       
        db = get_db()
        try:      
             if fileuploaded==1:
                db.execute(
                    'UPDATE Section SET section_name =?, section_description = ?, image = ?, image_name = ? '
                        ' WHERE  section_id = ? ',
                        (sectionname, desciption,  imagef, f.filename,  sectionid)    
                )
                db.commit()
                write_to_file(imagef,f.filename)
             else:
                db.execute(
                     'UPDATE Section SET section_name = ?, section_description = ? '
                        ' WHERE  section_id = ? ',
                        (sectionname, desciption,   sectionid) 
                )
                db.commit()
             
        except Exception as e:
            fileuploaded=0
            print(e)
    return redirect(url_for('cart.showAndModifySections'))

@bp.route('/delete_section/<string:code>')
@login_required
def delete_section(code):
    db = get_db()
    db.execute(
        'delete from section'
        ' WHERE section_id = ?',
        (code,)
    )
    db.commit()    
    return redirect(url_for('cart.showAndModifySections'))

@bp.route('/clearCart')
@login_required
def clearCart():
    try:
        cart_id = int(session['cart_id'])
        db = get_db()
        #delete cart items first
        db.execute(
            'delete from cart_item'
            ' WHERE cart_id = ?',
            (cart_id,)
        )
        db.commit()
  
        db.execute(
            'UPDATE Cart SET total_price = ?, total_quantity = ?'
            ' WHERE order_placed = \'No\' and cart_id = ? ',
            (0,0, cart_id)
        )
        db.commit()

        session.pop('all_total_quantity',None) 
        session.pop('all_total_price',None)
        session.pop('cart_item',None)

    except Exception as e:
        print(e)
    return redirect(url_for('cart.SearchAndAdd', fromPage='addToCart',productid=None ))

@bp.route('/generateInvoice')
@login_required
def generateInvoice():   
    cartid=-1
    try:  
        session['inError'] = 'No'
        #first save cart    
        save_cart()
        dd = date.today()
        name = session['user_id']
        db = get_db()
        cartitems = db.execute(
            'select product.product_id,product_name,product_quantity,price,total_price, cart_id from cart_Item, product where cart_item.cart_id in (select cart_id from cart where order_placed=\'No\' and user_id = ?) and cart_Item.product_id = Product.product_id', (name,)
        ).fetchall()   
        userdetails = db.execute(
            'select username, user_id, firstname, lastname, phone, shipping_addr, city, state, country, PIN from user where user_id = ?', (name,)
        ).fetchone()
    
        print("I am here in genrate Invoice")
        cartid=''
        if (cartitems is not None):
            for cart in cartitems:
                cartid = cart['cart_id']
                break
            if cartid == '':
                raise TypeError('Add atleast one item to the Cart.')
            
    except Exception as e:
        print('in exception ' + str(e))
        flash(e)
        session['inError'] = 'Yes'
    finally:
        return render_template('cart/generateInvoice.html', date = dd, name = name, userdetails=userdetails, orders = cartitems, cartid=cartid)   

@bp.route('/place_order/<string:code>')
@login_required
def place_order(code):
    print('cart id for order creation =' + code)
    if int(code) != -1: 
        productArray = {} 
        dd = date.today()
        db = get_db()
        print('order date='+str(dd))
        cart = db.execute(
            'select total_price,total_quantity from cart where cart_id = ?', (code,)
        ).fetchall()

        if cart[0]['total_quantity'] > 0:
            cartitems = db.execute(
                'select cart_item_id,cart_id,product_id,product_quantity,total_price from cart_item where cart_id = ?', (code,)
            ).fetchall()
            
            userid = session['user_id']
            if cartitems is not None:
                #first generate order from cart
                print('cart totals='+ str(cart[0]['total_price']) +  str(cart[0]['total_quantity']) + str(userid))
                db.execute('insert into orders (total_price,total_quantity,user_id, cart_id, order_date) values (?,?,?,?,?) ', (float(cart[0]['total_price']), int(cart[0]['total_quantity']), int(userid), int(code), str(dd),))     
                db.commit()
                ord = db.execute(
                    'select order_id from orders where cart_id = ?', (code,)
                ).fetchone() 
                #second generate order items from cart items
                for cartitem in cartitems:
                    db.execute(
                        'insert into order_item (order_id,product_id, product_quantity, total_price, cart_item_id) values(?,?,?,?,?)', 
                        (ord['order_id'], cartitem['product_id'],cartitem['product_quantity'],cartitem['total_price'],cartitem['cart_item_id'],)
                    )
                    productArray[cartitem['product_id']]=cartitem['product_quantity']
                db.commit()
                #reduce inventory quanties on the product table
                products = db.execute(
                    'select product_id,available_qty from product where product_id  in (select product_id from cart_item where cart_id = ?)',(code,)).fetchall()
            
                for product in products:
                    db.execute(
                        'UPDATE product SET available_qty = ?'
                        ' WHERE product_id = ?',
                        (int(product['available_qty']) - productArray[product['product_id']], product['product_id'])
                    )
                    db.commit()
                #update Cart to Order place=yes
                db.execute(
                        'UPDATE cart SET order_placed = \'Yes\''
                        ' WHERE cart_id = ?',
                        (code,)
                )
                db.commit()
                session.pop('all_total_quantity',None) 
                session.pop('all_total_price',None)
                session.pop('cart_item',None)
                session.pop('cart_id',None)
    return redirect(url_for('cart.SearchAndAdd', fromPage='generateInvoice',productid=None))

@bp.route('/home_orders/', methods=('GET','POST'))
@login_required
def home_orders():
   userid = session['user_id']
   finalquery = 'select order_id, total_quantity, order_status, total_price, strftime(\'%d-%m-%Y\', order_date) as order_date from orders p where user_id = ' + str(userid)
  
   db = get_db()
   sections = db.execute(
        finalquery
   ).fetchall()
  
   print('finalquery = ' +finalquery)
   orders = db.execute(finalquery).fetchall() 
   print('userid='+str(userid))
   return render_template('cart/showOrders.html', orders=orders)
