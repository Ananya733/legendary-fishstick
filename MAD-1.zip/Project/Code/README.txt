Python 3 is required along with flask and the following modules:-
1. sqlite3
2. functools
3. os
4. datetime
5. werkzeug.security

STEP-1 : redirect to the folder Project/Code
STEP-2 : run the python file __init__.py
STEP-3 : link will be generated, open the link using ctrl+click. You can start using the application as admin or end user.
